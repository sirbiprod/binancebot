package binance_api

type ErrorResponse struct {
	Code string `json:"code"`
}
