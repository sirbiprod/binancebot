package account

type Information struct {
	Email string
}
