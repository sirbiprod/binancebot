# Bot for automatic purchase of boxes

```text
Setting - https://telegra.ph/Setting-Binance-NFT-Buy-09-01
```

Create .env file in root directory and add following values:
```dotenv
PROXY=login:password@host:port (optional)
CSRFTOKEN=223ca53de22ed3bf3986691b555b276
COOKIE=cid=ELvvC1Ko; _ga=GA1.2.733926612.1630033029; bnc-uuid=6317d211-e2b5-4658-a189-578423c07774...
```